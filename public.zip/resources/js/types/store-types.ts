interface GeneralSettingState {
  setting: { [key: string]: any };
}
