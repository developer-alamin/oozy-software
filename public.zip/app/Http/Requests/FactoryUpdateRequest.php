<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

class FactoryUpdateRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $factoryId = $this->route('uuid');

        return [
            'company_id'        => 'required|exists:companies,id',
            'name'              => "required|string|max:255",
            'email'            => 'nullable|email',
            'phone'            => 'nullable|string',
            'location'         => 'nullable|string',
            'factory_code'     => 'nullable|string|max:50',
            'factory_owner'    => 'nullable|string',
            'factory_size'     => 'nullable|string',
            'factory_capacity' => 'nullable|string',
            'note'             => 'nullable|string',
            'status'           => 'required|in:Active,Inactive',
        ];
    }
}