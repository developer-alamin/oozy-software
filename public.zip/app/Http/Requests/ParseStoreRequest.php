<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ParseStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'company_id'              => 'required|exists:companies,id',
            'factory_id'              => 'required|exists:factories,id',
            'category_id'             => 'required|exists:categories,id',
            'supplier_name'           => 'required',
            'brand_name'              => 'required',
            'model_name'              => 'required',
            'parse_unit_id'           => 'required|exists:parse_units,id',
            'name'                    => 'required|string|max:255',
            'quantity'                => 'nullable|numeric',
            'purchase_price'          => 'nullable|numeric',
            'purchase_date'           => 'nullable',
            'status'                  => 'nullable',  // Example: assumes "status" has specific values
            'note'                    => 'nullable|string',
        ];
    }
}
